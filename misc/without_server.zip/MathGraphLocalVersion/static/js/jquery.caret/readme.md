jQuery Caret
============

- get the caret's position: `pos = $(textarea).caret()`
- set the caret's position: `$(textarea).caret(pos)`
- set the caret's position to the end: `$(textarea).caret(-1)`

Return value: the current/new caret position